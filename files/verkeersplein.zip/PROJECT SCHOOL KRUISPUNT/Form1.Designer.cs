﻿
namespace PROJECT_SCHOOL_KRUISPUNT
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.btnStart = new System.Windows.Forms.Button();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.button1 = new System.Windows.Forms.Button();
            this.timer3 = new System.Windows.Forms.Timer(this.components);
            this.timer4 = new System.Windows.Forms.Timer(this.components);
            this.timer5 = new System.Windows.Forms.Timer(this.components);
            this.timer6 = new System.Windows.Forms.Timer(this.components);
            this.button2 = new System.Windows.Forms.Button();
            this.timer7 = new System.Windows.Forms.Timer(this.components);
            this.PolitieAuto = new System.Windows.Forms.PictureBox();
            this.AutoLinks = new System.Windows.Forms.PictureBox();
            this.StoplichtVoetRed1 = new System.Windows.Forms.PictureBox();
            this.Redstoplight2 = new System.Windows.Forms.PictureBox();
            this.Greenstoplight2 = new System.Windows.Forms.PictureBox();
            this.Yellowstoplight2 = new System.Windows.Forms.PictureBox();
            this.stoplightoff2 = new System.Windows.Forms.PictureBox();
            this.Greenstoplight3 = new System.Windows.Forms.PictureBox();
            this.Yellowstoplight3 = new System.Windows.Forms.PictureBox();
            this.Redstoplight3 = new System.Windows.Forms.PictureBox();
            this.stoplightoff3 = new System.Windows.Forms.PictureBox();
            this.Greenstoplight1 = new System.Windows.Forms.PictureBox();
            this.Yellowstoplight1 = new System.Windows.Forms.PictureBox();
            this.stoplightoff1 = new System.Windows.Forms.PictureBox();
            this.Redstoplight1 = new System.Windows.Forms.PictureBox();
            this.Redstoplight = new System.Windows.Forms.PictureBox();
            this.Yellowstoplight = new System.Windows.Forms.PictureBox();
            this.Greenstoplight = new System.Windows.Forms.PictureBox();
            this.stoplightoff = new System.Windows.Forms.PictureBox();
            this.voetganger2 = new System.Windows.Forms.PictureBox();
            this.voetganger3 = new System.Windows.Forms.PictureBox();
            this.StoplichtVoetRed3 = new System.Windows.Forms.PictureBox();
            this.StoplichtVoetRed4 = new System.Windows.Forms.PictureBox();
            this.StoplichtVoetRed2 = new System.Windows.Forms.PictureBox();
            this.StoplichtVoetGreen2 = new System.Windows.Forms.PictureBox();
            this.StoplichtVoetGreen4 = new System.Windows.Forms.PictureBox();
            this.StoplichtVoetGreen3 = new System.Windows.Forms.PictureBox();
            this.StoplichtVoetGreen1 = new System.Windows.Forms.PictureBox();
            this.voetganger1 = new System.Windows.Forms.PictureBox();
            this.voetganger4 = new System.Windows.Forms.PictureBox();
            this.pictureBox17 = new System.Windows.Forms.PictureBox();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.Blackcar = new System.Windows.Forms.PictureBox();
            this.AutoRechts = new System.Windows.Forms.PictureBox();
            this.Picturebox = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.PolitieAuto)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.AutoLinks)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.StoplichtVoetRed1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Redstoplight2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Greenstoplight2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Yellowstoplight2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stoplightoff2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Greenstoplight3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Yellowstoplight3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Redstoplight3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stoplightoff3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Greenstoplight1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Yellowstoplight1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stoplightoff1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Redstoplight1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Redstoplight)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Yellowstoplight)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Greenstoplight)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stoplightoff)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.voetganger2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.voetganger3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.StoplichtVoetRed3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.StoplichtVoetRed4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.StoplichtVoetRed2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.StoplichtVoetGreen2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.StoplichtVoetGreen4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.StoplichtVoetGreen3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.StoplichtVoetGreen1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.voetganger1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.voetganger4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Blackcar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.AutoRechts)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Picturebox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 5000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(987, 12);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(96, 47);
            this.btnStart.TabIndex = 30;
            this.btnStart.Text = "Start simulatie";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // timer2
            // 
            this.timer2.Enabled = true;
            this.timer2.Interval = 13000;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(893, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(88, 47);
            this.button1.TabIndex = 61;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // timer3
            // 
            this.timer3.Interval = 3000;
            this.timer3.Tick += new System.EventHandler(this.timer3_Tick);
            // 
            // timer4
            // 
            this.timer4.Tick += new System.EventHandler(this.timer4_Tick);
            // 
            // timer5
            // 
            this.timer5.Tick += new System.EventHandler(this.timer5_Tick);
            // 
            // timer6
            // 
            this.timer6.Tick += new System.EventHandler(this.timer6_Tick);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(798, 12);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(89, 47);
            this.button2.TabIndex = 62;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // timer7
            // 
            this.timer7.Interval = 1000;
            this.timer7.Tick += new System.EventHandler(this.timer7_Tick);
            // 
            // PolitieAuto
            // 
            this.PolitieAuto.Image = global::PROJECT_SCHOOL_KRUISPUNT.Properties.Resources.Politieauto;
            this.PolitieAuto.Location = new System.Drawing.Point(464, 68);
            this.PolitieAuto.Name = "PolitieAuto";
            this.PolitieAuto.Size = new System.Drawing.Size(66, 131);
            this.PolitieAuto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PolitieAuto.TabIndex = 63;
            this.PolitieAuto.TabStop = false;
            // 
            // AutoLinks
            // 
            this.AutoLinks.Image = global::PROJECT_SCHOOL_KRUISPUNT.Properties.Resources.PngItem_1232481;
            this.AutoLinks.Location = new System.Drawing.Point(274, 323);
            this.AutoLinks.Name = "AutoLinks";
            this.AutoLinks.Size = new System.Drawing.Size(130, 66);
            this.AutoLinks.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.AutoLinks.TabIndex = 60;
            this.AutoLinks.TabStop = false;
            // 
            // StoplichtVoetRed1
            // 
            this.StoplichtVoetRed1.Image = global::PROJECT_SCHOOL_KRUISPUNT.Properties.Resources.Voetgangerstoplicht;
            this.StoplichtVoetRed1.Location = new System.Drawing.Point(392, 157);
            this.StoplichtVoetRed1.Name = "StoplichtVoetRed1";
            this.StoplichtVoetRed1.Size = new System.Drawing.Size(46, 63);
            this.StoplichtVoetRed1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.StoplichtVoetRed1.TabIndex = 34;
            this.StoplichtVoetRed1.TabStop = false;
            this.StoplichtVoetRed1.Click += new System.EventHandler(this.VoetgangersLBRood_Click);
            // 
            // Redstoplight2
            // 
            this.Redstoplight2.Image = global::PROJECT_SCHOOL_KRUISPUNT.Properties.Resources.Traffic_light_red;
            this.Redstoplight2.Location = new System.Drawing.Point(485, 226);
            this.Redstoplight2.Name = "Redstoplight2";
            this.Redstoplight2.Size = new System.Drawing.Size(37, 74);
            this.Redstoplight2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Redstoplight2.TabIndex = 46;
            this.Redstoplight2.TabStop = false;
            this.Redstoplight2.Click += new System.EventHandler(this.Redstoplight2_Click);
            // 
            // Greenstoplight2
            // 
            this.Greenstoplight2.Image = global::PROJECT_SCHOOL_KRUISPUNT.Properties.Resources.Traffic_light_green;
            this.Greenstoplight2.Location = new System.Drawing.Point(485, 226);
            this.Greenstoplight2.Name = "Greenstoplight2";
            this.Greenstoplight2.Size = new System.Drawing.Size(37, 74);
            this.Greenstoplight2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Greenstoplight2.TabIndex = 51;
            this.Greenstoplight2.TabStop = false;
            // 
            // Yellowstoplight2
            // 
            this.Yellowstoplight2.Image = global::PROJECT_SCHOOL_KRUISPUNT.Properties.Resources.Traffic_light_yellow_2;
            this.Yellowstoplight2.Location = new System.Drawing.Point(485, 226);
            this.Yellowstoplight2.Name = "Yellowstoplight2";
            this.Yellowstoplight2.Size = new System.Drawing.Size(37, 74);
            this.Yellowstoplight2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Yellowstoplight2.TabIndex = 48;
            this.Yellowstoplight2.TabStop = false;
            // 
            // stoplightoff2
            // 
            this.stoplightoff2.Image = global::PROJECT_SCHOOL_KRUISPUNT.Properties.Resources.stoplight_off;
            this.stoplightoff2.Location = new System.Drawing.Point(485, 226);
            this.stoplightoff2.Name = "stoplightoff2";
            this.stoplightoff2.Size = new System.Drawing.Size(37, 74);
            this.stoplightoff2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.stoplightoff2.TabIndex = 58;
            this.stoplightoff2.TabStop = false;
            // 
            // Greenstoplight3
            // 
            this.Greenstoplight3.Image = global::PROJECT_SCHOOL_KRUISPUNT.Properties.Resources.Traffic_light_green;
            this.Greenstoplight3.Location = new System.Drawing.Point(587, 323);
            this.Greenstoplight3.Name = "Greenstoplight3";
            this.Greenstoplight3.Size = new System.Drawing.Size(37, 74);
            this.Greenstoplight3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Greenstoplight3.TabIndex = 25;
            this.Greenstoplight3.TabStop = false;
            // 
            // Yellowstoplight3
            // 
            this.Yellowstoplight3.Image = global::PROJECT_SCHOOL_KRUISPUNT.Properties.Resources.Traffic_light_yellow_2;
            this.Yellowstoplight3.Location = new System.Drawing.Point(587, 324);
            this.Yellowstoplight3.Name = "Yellowstoplight3";
            this.Yellowstoplight3.Size = new System.Drawing.Size(37, 74);
            this.Yellowstoplight3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Yellowstoplight3.TabIndex = 28;
            this.Yellowstoplight3.TabStop = false;
            this.Yellowstoplight3.Click += new System.EventHandler(this.StoplichtGeelRO_Click);
            // 
            // Redstoplight3
            // 
            this.Redstoplight3.BackColor = System.Drawing.Color.ForestGreen;
            this.Redstoplight3.Image = global::PROJECT_SCHOOL_KRUISPUNT.Properties.Resources.Traffic_light_red;
            this.Redstoplight3.Location = new System.Drawing.Point(587, 324);
            this.Redstoplight3.Name = "Redstoplight3";
            this.Redstoplight3.Size = new System.Drawing.Size(37, 74);
            this.Redstoplight3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Redstoplight3.TabIndex = 29;
            this.Redstoplight3.TabStop = false;
            // 
            // stoplightoff3
            // 
            this.stoplightoff3.Image = global::PROJECT_SCHOOL_KRUISPUNT.Properties.Resources.stoplight_off;
            this.stoplightoff3.Location = new System.Drawing.Point(587, 324);
            this.stoplightoff3.Name = "stoplightoff3";
            this.stoplightoff3.Size = new System.Drawing.Size(37, 74);
            this.stoplightoff3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.stoplightoff3.TabIndex = 59;
            this.stoplightoff3.TabStop = false;
            // 
            // Greenstoplight1
            // 
            this.Greenstoplight1.Image = global::PROJECT_SCHOOL_KRUISPUNT.Properties.Resources.Traffic_light_green;
            this.Greenstoplight1.Location = new System.Drawing.Point(587, 226);
            this.Greenstoplight1.Name = "Greenstoplight1";
            this.Greenstoplight1.Size = new System.Drawing.Size(37, 74);
            this.Greenstoplight1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Greenstoplight1.TabIndex = 53;
            this.Greenstoplight1.TabStop = false;
            // 
            // Yellowstoplight1
            // 
            this.Yellowstoplight1.Image = global::PROJECT_SCHOOL_KRUISPUNT.Properties.Resources.Traffic_light_yellow_2;
            this.Yellowstoplight1.Location = new System.Drawing.Point(587, 226);
            this.Yellowstoplight1.Name = "Yellowstoplight1";
            this.Yellowstoplight1.Size = new System.Drawing.Size(37, 74);
            this.Yellowstoplight1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Yellowstoplight1.TabIndex = 50;
            this.Yellowstoplight1.TabStop = false;
            this.Yellowstoplight1.Click += new System.EventHandler(this.Stoplichtgeel2_Click);
            // 
            // stoplightoff1
            // 
            this.stoplightoff1.Image = global::PROJECT_SCHOOL_KRUISPUNT.Properties.Resources.stoplight_off;
            this.stoplightoff1.Location = new System.Drawing.Point(587, 226);
            this.stoplightoff1.Name = "stoplightoff1";
            this.stoplightoff1.Size = new System.Drawing.Size(37, 74);
            this.stoplightoff1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.stoplightoff1.TabIndex = 56;
            this.stoplightoff1.TabStop = false;
            this.stoplightoff1.Click += new System.EventHandler(this.StoplichtOff1_Click);
            // 
            // Redstoplight1
            // 
            this.Redstoplight1.Image = global::PROJECT_SCHOOL_KRUISPUNT.Properties.Resources.Traffic_light_red;
            this.Redstoplight1.Location = new System.Drawing.Point(587, 226);
            this.Redstoplight1.Name = "Redstoplight1";
            this.Redstoplight1.Size = new System.Drawing.Size(37, 74);
            this.Redstoplight1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Redstoplight1.TabIndex = 31;
            this.Redstoplight1.TabStop = false;
            // 
            // Redstoplight
            // 
            this.Redstoplight.Image = global::PROJECT_SCHOOL_KRUISPUNT.Properties.Resources.Traffic_light_red;
            this.Redstoplight.Location = new System.Drawing.Point(485, 324);
            this.Redstoplight.Name = "Redstoplight";
            this.Redstoplight.Size = new System.Drawing.Size(37, 74);
            this.Redstoplight.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Redstoplight.TabIndex = 47;
            this.Redstoplight.TabStop = false;
            this.Redstoplight.Click += new System.EventHandler(this.Redstoplight_Click);
            // 
            // Yellowstoplight
            // 
            this.Yellowstoplight.Image = global::PROJECT_SCHOOL_KRUISPUNT.Properties.Resources.Traffic_light_yellow_2;
            this.Yellowstoplight.Location = new System.Drawing.Point(485, 324);
            this.Yellowstoplight.Name = "Yellowstoplight";
            this.Yellowstoplight.Size = new System.Drawing.Size(37, 74);
            this.Yellowstoplight.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Yellowstoplight.TabIndex = 49;
            this.Yellowstoplight.TabStop = false;
            // 
            // Greenstoplight
            // 
            this.Greenstoplight.Image = global::PROJECT_SCHOOL_KRUISPUNT.Properties.Resources.Traffic_light_green;
            this.Greenstoplight.Location = new System.Drawing.Point(485, 324);
            this.Greenstoplight.Name = "Greenstoplight";
            this.Greenstoplight.Size = new System.Drawing.Size(37, 74);
            this.Greenstoplight.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Greenstoplight.TabIndex = 52;
            this.Greenstoplight.TabStop = false;
            // 
            // stoplightoff
            // 
            this.stoplightoff.Image = global::PROJECT_SCHOOL_KRUISPUNT.Properties.Resources.stoplight_off;
            this.stoplightoff.Location = new System.Drawing.Point(485, 323);
            this.stoplightoff.Name = "stoplightoff";
            this.stoplightoff.Size = new System.Drawing.Size(37, 74);
            this.stoplightoff.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.stoplightoff.TabIndex = 57;
            this.stoplightoff.TabStop = false;
            // 
            // voetganger2
            // 
            this.voetganger2.BackColor = System.Drawing.Color.Green;
            this.voetganger2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.voetganger2.Image = global::PROJECT_SCHOOL_KRUISPUNT.Properties.Resources.NicePng_people_top_view_png_8618582;
            this.voetganger2.Location = new System.Drawing.Point(681, 404);
            this.voetganger2.Name = "voetganger2";
            this.voetganger2.Size = new System.Drawing.Size(46, 54);
            this.voetganger2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.voetganger2.TabIndex = 55;
            this.voetganger2.TabStop = false;
            // 
            // voetganger3
            // 
            this.voetganger3.BackColor = System.Drawing.Color.Green;
            this.voetganger3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.voetganger3.Image = global::PROJECT_SCHOOL_KRUISPUNT.Properties.Resources.NicePng_people_top_view_png_8618582;
            this.voetganger3.Location = new System.Drawing.Point(392, 404);
            this.voetganger3.Name = "voetganger3";
            this.voetganger3.Size = new System.Drawing.Size(46, 54);
            this.voetganger3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.voetganger3.TabIndex = 54;
            this.voetganger3.TabStop = false;
            // 
            // StoplichtVoetRed3
            // 
            this.StoplichtVoetRed3.Image = global::PROJECT_SCHOOL_KRUISPUNT.Properties.Resources.Voetgangerstoplicht;
            this.StoplichtVoetRed3.Location = new System.Drawing.Point(392, 464);
            this.StoplichtVoetRed3.Name = "StoplichtVoetRed3";
            this.StoplichtVoetRed3.Size = new System.Drawing.Size(46, 63);
            this.StoplichtVoetRed3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.StoplichtVoetRed3.TabIndex = 45;
            this.StoplichtVoetRed3.TabStop = false;
            // 
            // StoplichtVoetRed4
            // 
            this.StoplichtVoetRed4.Image = global::PROJECT_SCHOOL_KRUISPUNT.Properties.Resources.Voetgangerstoplicht;
            this.StoplichtVoetRed4.Location = new System.Drawing.Point(681, 464);
            this.StoplichtVoetRed4.Name = "StoplichtVoetRed4";
            this.StoplichtVoetRed4.Size = new System.Drawing.Size(46, 63);
            this.StoplichtVoetRed4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.StoplichtVoetRed4.TabIndex = 44;
            this.StoplichtVoetRed4.TabStop = false;
            // 
            // StoplichtVoetRed2
            // 
            this.StoplichtVoetRed2.Image = global::PROJECT_SCHOOL_KRUISPUNT.Properties.Resources.Voetgangerstoplicht;
            this.StoplichtVoetRed2.Location = new System.Drawing.Point(658, 157);
            this.StoplichtVoetRed2.Name = "StoplichtVoetRed2";
            this.StoplichtVoetRed2.Size = new System.Drawing.Size(46, 63);
            this.StoplichtVoetRed2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.StoplichtVoetRed2.TabIndex = 43;
            this.StoplichtVoetRed2.TabStop = false;
            // 
            // StoplichtVoetGreen2
            // 
            this.StoplichtVoetGreen2.Image = global::PROJECT_SCHOOL_KRUISPUNT.Properties.Resources.Voetgangersstoplicht_Groen;
            this.StoplichtVoetGreen2.Location = new System.Drawing.Point(658, 157);
            this.StoplichtVoetGreen2.Name = "StoplichtVoetGreen2";
            this.StoplichtVoetGreen2.Size = new System.Drawing.Size(46, 63);
            this.StoplichtVoetGreen2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.StoplichtVoetGreen2.TabIndex = 41;
            this.StoplichtVoetGreen2.TabStop = false;
            // 
            // StoplichtVoetGreen4
            // 
            this.StoplichtVoetGreen4.Image = global::PROJECT_SCHOOL_KRUISPUNT.Properties.Resources.Voetgangersstoplicht_Groen;
            this.StoplichtVoetGreen4.Location = new System.Drawing.Point(681, 464);
            this.StoplichtVoetGreen4.Name = "StoplichtVoetGreen4";
            this.StoplichtVoetGreen4.Size = new System.Drawing.Size(46, 63);
            this.StoplichtVoetGreen4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.StoplichtVoetGreen4.TabIndex = 40;
            this.StoplichtVoetGreen4.TabStop = false;
            // 
            // StoplichtVoetGreen3
            // 
            this.StoplichtVoetGreen3.Image = global::PROJECT_SCHOOL_KRUISPUNT.Properties.Resources.Voetgangersstoplicht_Groen;
            this.StoplichtVoetGreen3.Location = new System.Drawing.Point(392, 464);
            this.StoplichtVoetGreen3.Name = "StoplichtVoetGreen3";
            this.StoplichtVoetGreen3.Size = new System.Drawing.Size(46, 63);
            this.StoplichtVoetGreen3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.StoplichtVoetGreen3.TabIndex = 39;
            this.StoplichtVoetGreen3.TabStop = false;
            // 
            // StoplichtVoetGreen1
            // 
            this.StoplichtVoetGreen1.Image = global::PROJECT_SCHOOL_KRUISPUNT.Properties.Resources.Voetgangersstoplicht_Groen;
            this.StoplichtVoetGreen1.Location = new System.Drawing.Point(392, 157);
            this.StoplichtVoetGreen1.Name = "StoplichtVoetGreen1";
            this.StoplichtVoetGreen1.Size = new System.Drawing.Size(46, 63);
            this.StoplichtVoetGreen1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.StoplichtVoetGreen1.TabIndex = 37;
            this.StoplichtVoetGreen1.TabStop = false;
            // 
            // voetganger1
            // 
            this.voetganger1.BackColor = System.Drawing.Color.Green;
            this.voetganger1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.voetganger1.Image = global::PROJECT_SCHOOL_KRUISPUNT.Properties.Resources.NicePng_people_top_view_png_8618582;
            this.voetganger1.Location = new System.Drawing.Point(754, 166);
            this.voetganger1.Name = "voetganger1";
            this.voetganger1.Size = new System.Drawing.Size(46, 54);
            this.voetganger1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.voetganger1.TabIndex = 27;
            this.voetganger1.TabStop = false;
            // 
            // voetganger4
            // 
            this.voetganger4.BackColor = System.Drawing.Color.Green;
            this.voetganger4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.voetganger4.Image = global::PROJECT_SCHOOL_KRUISPUNT.Properties.Resources.NicePng_people_top_view_png_8618582;
            this.voetganger4.Location = new System.Drawing.Point(340, 166);
            this.voetganger4.Name = "voetganger4";
            this.voetganger4.Size = new System.Drawing.Size(46, 54);
            this.voetganger4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.voetganger4.TabIndex = 26;
            this.voetganger4.TabStop = false;
            // 
            // pictureBox17
            // 
            this.pictureBox17.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pictureBox17.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox17.Location = new System.Drawing.Point(549, 433);
            this.pictureBox17.Name = "pictureBox17";
            this.pictureBox17.Size = new System.Drawing.Size(13, 79);
            this.pictureBox17.TabIndex = 23;
            this.pictureBox17.TabStop = false;
            // 
            // pictureBox16
            // 
            this.pictureBox16.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pictureBox16.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox16.Location = new System.Drawing.Point(549, 534);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(13, 79);
            this.pictureBox16.TabIndex = 22;
            this.pictureBox16.TabStop = false;
            // 
            // pictureBox14
            // 
            this.pictureBox14.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pictureBox14.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox14.Location = new System.Drawing.Point(549, 108);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(13, 79);
            this.pictureBox14.TabIndex = 21;
            this.pictureBox14.TabStop = false;
            // 
            // pictureBox15
            // 
            this.pictureBox15.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pictureBox15.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox15.Location = new System.Drawing.Point(879, 304);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(79, 13);
            this.pictureBox15.TabIndex = 20;
            this.pictureBox15.TabStop = false;
            // 
            // pictureBox13
            // 
            this.pictureBox13.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pictureBox13.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox13.Location = new System.Drawing.Point(549, 12);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(13, 79);
            this.pictureBox13.TabIndex = 18;
            this.pictureBox13.TabStop = false;
            // 
            // pictureBox12
            // 
            this.pictureBox12.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pictureBox12.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox12.Location = new System.Drawing.Point(1004, 304);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(79, 13);
            this.pictureBox12.TabIndex = 17;
            this.pictureBox12.TabStop = false;
            // 
            // pictureBox11
            // 
            this.pictureBox11.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pictureBox11.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox11.Location = new System.Drawing.Point(742, 304);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(79, 13);
            this.pictureBox11.TabIndex = 16;
            this.pictureBox11.TabStop = false;
            // 
            // pictureBox10
            // 
            this.pictureBox10.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pictureBox10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox10.Location = new System.Drawing.Point(142, 304);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(79, 13);
            this.pictureBox10.TabIndex = 15;
            this.pictureBox10.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pictureBox9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox9.Location = new System.Drawing.Point(274, 304);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(79, 13);
            this.pictureBox9.TabIndex = 14;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pictureBox8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox8.Location = new System.Drawing.Point(12, 304);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(79, 13);
            this.pictureBox8.TabIndex = 13;
            this.pictureBox8.TabStop = false;
            // 
            // Blackcar
            // 
            this.Blackcar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Blackcar.Image = global::PROJECT_SCHOOL_KRUISPUNT.Properties.Resources.PngItem_1429707;
            this.Blackcar.Location = new System.Drawing.Point(587, 496);
            this.Blackcar.Name = "Blackcar";
            this.Blackcar.Size = new System.Drawing.Size(73, 148);
            this.Blackcar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Blackcar.TabIndex = 11;
            this.Blackcar.TabStop = false;
            // 
            // AutoRechts
            // 
            this.AutoRechts.Image = global::PROJECT_SCHOOL_KRUISPUNT.Properties.Resources.kisspng_car_clip_art_red_top_car_png_5ab18cf22f56b9_7533253315215853941939;
            this.AutoRechts.Location = new System.Drawing.Point(710, 226);
            this.AutoRechts.Name = "AutoRechts";
            this.AutoRechts.Size = new System.Drawing.Size(140, 81);
            this.AutoRechts.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.AutoRechts.TabIndex = 10;
            this.AutoRechts.TabStop = false;
            this.AutoRechts.Click += new System.EventHandler(this.AutoRechts_Click);
            // 
            // Picturebox
            // 
            this.Picturebox.BackColor = System.Drawing.Color.Green;
            this.Picturebox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Picturebox.Location = new System.Drawing.Point(666, 395);
            this.Picturebox.Name = "Picturebox";
            this.Picturebox.Size = new System.Drawing.Size(437, 218);
            this.Picturebox.TabIndex = 9;
            this.Picturebox.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Green;
            this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox2.Location = new System.Drawing.Point(658, 2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(437, 218);
            this.pictureBox2.TabIndex = 8;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Green;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox1.Location = new System.Drawing.Point(1, 395);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(437, 218);
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.Green;
            this.pictureBox4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox4.Location = new System.Drawing.Point(1, 2);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(437, 218);
            this.pictureBox4.TabIndex = 6;
            this.pictureBox4.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DimGray;
            this.ClientSize = new System.Drawing.Size(1095, 635);
            this.Controls.Add(this.PolitieAuto);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.AutoLinks);
            this.Controls.Add(this.StoplichtVoetRed1);
            this.Controls.Add(this.Redstoplight2);
            this.Controls.Add(this.Greenstoplight2);
            this.Controls.Add(this.Yellowstoplight2);
            this.Controls.Add(this.stoplightoff2);
            this.Controls.Add(this.Greenstoplight3);
            this.Controls.Add(this.Yellowstoplight3);
            this.Controls.Add(this.Redstoplight3);
            this.Controls.Add(this.stoplightoff3);
            this.Controls.Add(this.Greenstoplight1);
            this.Controls.Add(this.Yellowstoplight1);
            this.Controls.Add(this.stoplightoff1);
            this.Controls.Add(this.Redstoplight1);
            this.Controls.Add(this.Redstoplight);
            this.Controls.Add(this.Yellowstoplight);
            this.Controls.Add(this.Greenstoplight);
            this.Controls.Add(this.stoplightoff);
            this.Controls.Add(this.voetganger2);
            this.Controls.Add(this.voetganger3);
            this.Controls.Add(this.StoplichtVoetRed3);
            this.Controls.Add(this.StoplichtVoetRed4);
            this.Controls.Add(this.StoplichtVoetRed2);
            this.Controls.Add(this.StoplichtVoetGreen2);
            this.Controls.Add(this.StoplichtVoetGreen4);
            this.Controls.Add(this.StoplichtVoetGreen3);
            this.Controls.Add(this.StoplichtVoetGreen1);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.voetganger1);
            this.Controls.Add(this.voetganger4);
            this.Controls.Add(this.pictureBox17);
            this.Controls.Add(this.pictureBox16);
            this.Controls.Add(this.pictureBox14);
            this.Controls.Add(this.pictureBox15);
            this.Controls.Add(this.pictureBox13);
            this.Controls.Add(this.pictureBox12);
            this.Controls.Add(this.pictureBox11);
            this.Controls.Add(this.pictureBox10);
            this.Controls.Add(this.pictureBox9);
            this.Controls.Add(this.pictureBox8);
            this.Controls.Add(this.Blackcar);
            this.Controls.Add(this.AutoRechts);
            this.Controls.Add(this.Picturebox);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.pictureBox4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.PolitieAuto)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.AutoLinks)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.StoplichtVoetRed1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Redstoplight2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Greenstoplight2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Yellowstoplight2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stoplightoff2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Greenstoplight3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Yellowstoplight3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Redstoplight3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stoplightoff3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Greenstoplight1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Yellowstoplight1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stoplightoff1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Redstoplight1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Redstoplight)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Yellowstoplight)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Greenstoplight)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stoplightoff)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.voetganger2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.voetganger3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.StoplichtVoetRed3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.StoplichtVoetRed4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.StoplichtVoetRed2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.StoplichtVoetGreen2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.StoplichtVoetGreen4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.StoplichtVoetGreen3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.StoplichtVoetGreen1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.voetganger1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.voetganger4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Blackcar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.AutoRechts)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Picturebox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox AutoRechts;
        private System.Windows.Forms.PictureBox Blackcar;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.PictureBox pictureBox16;
        private System.Windows.Forms.PictureBox pictureBox17;
        private System.Windows.Forms.PictureBox Greenstoplight3;
        private System.Windows.Forms.PictureBox voetganger4;
        private System.Windows.Forms.PictureBox voetganger1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.PictureBox Redstoplight1;
        private System.Windows.Forms.PictureBox StoplichtVoetRed1;
        private System.Windows.Forms.PictureBox StoplichtVoetGreen1;
        private System.Windows.Forms.PictureBox StoplichtVoetGreen3;
        private System.Windows.Forms.PictureBox StoplichtVoetGreen4;
        private System.Windows.Forms.PictureBox StoplichtVoetGreen2;
        private System.Windows.Forms.PictureBox StoplichtVoetRed2;
        private System.Windows.Forms.PictureBox StoplichtVoetRed4;
        private System.Windows.Forms.PictureBox StoplichtVoetRed3;
        private System.Windows.Forms.PictureBox Yellowstoplight3;
        private System.Windows.Forms.PictureBox Redstoplight3;
        private System.Windows.Forms.PictureBox Redstoplight2;
        private System.Windows.Forms.PictureBox Redstoplight;
        private System.Windows.Forms.PictureBox Yellowstoplight2;
        private System.Windows.Forms.PictureBox Yellowstoplight;
        private System.Windows.Forms.PictureBox Yellowstoplight1;
        private System.Windows.Forms.PictureBox Greenstoplight2;
        private System.Windows.Forms.PictureBox Greenstoplight;
        private System.Windows.Forms.PictureBox Greenstoplight1;
        private System.Windows.Forms.PictureBox voetganger3;
        private System.Windows.Forms.PictureBox voetganger2;
        private System.Windows.Forms.PictureBox stoplightoff1;
        private System.Windows.Forms.PictureBox stoplightoff;
        private System.Windows.Forms.PictureBox stoplightoff2;
        private System.Windows.Forms.PictureBox stoplightoff3;
        private System.Windows.Forms.PictureBox Picturebox;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.PictureBox AutoLinks;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Timer timer3;
        private System.Windows.Forms.Timer timer4;
        private System.Windows.Forms.Timer timer5;
        private System.Windows.Forms.Timer timer6;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Timer timer7;
        private System.Windows.Forms.PictureBox PolitieAuto;
    }
}


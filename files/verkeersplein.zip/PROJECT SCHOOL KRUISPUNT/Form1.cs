﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PROJECT_SCHOOL_KRUISPUNT
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Redstoplight.Visible = true;

            Yellowstoplight.Visible = false;

            Greenstoplight.Visible = false;

            stoplightoff.Visible = false;

            Redstoplight1.Visible = true;

            Yellowstoplight1.Visible = false;

            Greenstoplight1.Visible = false;

            stoplightoff1.Visible = false;

            Redstoplight2.Visible = true;

            Yellowstoplight2.Visible = false;

            Greenstoplight2.Visible = false;

            stoplightoff2.Visible = false;

            Redstoplight3.Visible = true;

            Yellowstoplight3.Visible = false;

            Greenstoplight3.Visible = false;

            stoplightoff3.Visible = false;

            StoplichtVoetGreen1.Visible = false;

            StoplichtVoetRed1.Visible = true;

            StoplichtVoetGreen2.Visible = false;

            StoplichtVoetRed2.Visible = true;

            StoplichtVoetGreen3.Visible = false;

            StoplichtVoetRed3.Visible = true;

            StoplichtVoetGreen4.Visible = false;

            StoplichtVoetRed4.Visible = true;

            PolitieAuto.Visible = false;










        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
            
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            timer2.Enabled = true;
            
            
        }
        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Enabled = false;

            timer2.Enabled = false;

            timer3.Enabled = true;

            timer6.Enabled = true;

            timer4.Enabled = false;

            PolitieAuto.Visible = true;

            Redstoplight.Visible = true;

            Yellowstoplight.Visible = false;

            Greenstoplight.Visible = false;

            stoplightoff.Visible = false;

            Redstoplight1.Visible = true;

            Yellowstoplight1.Visible = false;

            Greenstoplight1.Visible = false;

            stoplightoff1.Visible = false;

            Redstoplight2.Visible = true;

            Yellowstoplight2.Visible = false;

            Greenstoplight2.Visible = false;

            stoplightoff2.Visible = false;

            Redstoplight3.Visible = true;

            Yellowstoplight3.Visible = false;

            Greenstoplight3.Visible = false;

            StoplichtVoetGreen1.Visible = false;

            StoplichtVoetRed1.Visible = true;

            StoplichtVoetGreen2.Visible = false;

            StoplichtVoetRed2.Visible = true;

            StoplichtVoetGreen3.Visible = false;

            StoplichtVoetRed3.Visible = true;

            StoplichtVoetGreen4.Visible = false;

            StoplichtVoetRed4.Visible = true;
        }
       
        private void timer1_Tick(object sender, EventArgs e)
        {


            if (Redstoplight.Visible == true)

            {

                timer1.Interval = 5000;

                Redstoplight.Visible = false;

                Yellowstoplight.Visible = false;

                Greenstoplight.Visible = true;

                StoplichtVoetGreen2.Visible = true;

                StoplichtVoetRed2.Visible = false;

                Redstoplight1.Visible = false;

                Yellowstoplight1.Visible = false;

                Greenstoplight1.Visible = true;

                StoplichtVoetGreen3.Visible = true;

                StoplichtVoetRed3.Visible = false;

                timer4.Enabled = true;



            }

            else if (Greenstoplight.Visible == true)

            {

                timer1.Interval = 2000;

                Redstoplight.Visible = false;

                Yellowstoplight.Visible = true;

                Greenstoplight.Visible = false;

                StoplichtVoetGreen2.Visible = false;

                StoplichtVoetRed2.Visible = true;

                Redstoplight1.Visible = false;

                Yellowstoplight1.Visible = true;

                Greenstoplight1.Visible = false;

                StoplichtVoetGreen3.Visible = false;

                StoplichtVoetRed3.Visible = true;

            }

            else if (Yellowstoplight.Visible == true)

            {

                timer1.Interval = 10000;

                Redstoplight.Visible = true;

                Yellowstoplight.Visible = false;

                Greenstoplight.Visible = false;

                StoplichtVoetGreen2.Visible = false;

                StoplichtVoetRed2.Visible = true;

                Redstoplight1.Visible = true;

                Yellowstoplight1.Visible = false;

                Greenstoplight1.Visible = false;

                StoplichtVoetGreen3.Visible = false;

                StoplichtVoetRed3.Visible = true;

                timer4.Enabled = false;

            }








        }

        private void StoplichtOff1_Click(object sender, EventArgs e)
        {

        }

        private void Stoplichtgeel2_Click(object sender, EventArgs e)
        {

        }

        private void AutoRechts_Click(object sender, EventArgs e)
        {
           
        }

        private void VoetgangersLBRood_Click(object sender, EventArgs e)
        {

        }

        private void timer2_Tick(object sender, EventArgs e)
        {

            

                if (Redstoplight2.Visible == true)

                {

                    timer2.Interval = 5000;

                    Redstoplight2.Visible = false;

                    Yellowstoplight2.Visible = false;

                    Greenstoplight2.Visible = true;

                    StoplichtVoetGreen1.Visible = true;

                    StoplichtVoetRed1.Visible = false;

                    Redstoplight3.Visible = false;

                    Yellowstoplight3.Visible = false;

                    Greenstoplight3.Visible = true;

                    StoplichtVoetGreen4.Visible = true;

                    StoplichtVoetRed4.Visible = false;

                    timer5.Enabled = true;



                }

                else if (Greenstoplight2.Visible == true)

                {

                    timer2.Interval = 2000;

                    Redstoplight2.Visible = false;

                    Yellowstoplight2.Visible = true;

                    Greenstoplight2.Visible = false;

                    StoplichtVoetGreen1.Visible = false;

                    StoplichtVoetRed1.Visible = true;

                    Redstoplight3.Visible = false;

                    Yellowstoplight3.Visible = true;

                    Greenstoplight3.Visible = false;

                    StoplichtVoetGreen4.Visible = false;

                    StoplichtVoetRed4.Visible = true;

                    timer5.Enabled = false;

                }

                else if (Yellowstoplight2.Visible == true)

                {

                    timer2.Interval = 10000;

                    Redstoplight2.Visible = true;

                    Yellowstoplight2.Visible = false;

                    Greenstoplight2.Visible = true;

                    StoplichtVoetGreen1.Visible = false;

                    StoplichtVoetRed1.Visible = true;

                    Redstoplight3.Visible = true;

                    Yellowstoplight3.Visible = false;

                    Greenstoplight3.Visible = false;

                    StoplichtVoetGreen4.Visible = false;

                    StoplichtVoetRed4.Visible = true;





                }



            }
        private void timer3_Tick(object sender, EventArgs e)
        {
            timer1.Enabled = true;

            timer2.Enabled = true;

            timer3.Enabled = false;
        }
      private void timer4_Tick(object sender, EventArgs e)
        {
            if (AutoRechts.Left >= 2)

            {

                AutoRechts.Location = new Point(AutoRechts.Location.X - 100, AutoRechts.Location.Y);

                AutoLinks.Location = new Point(AutoLinks.Location.X + 100, AutoLinks.Location.Y);

                voetganger2.Location = new Point(voetganger2.Location.X - 5, voetganger2.Location.Y);

                voetganger3.Location = new Point(voetganger3.Location.X + 5, voetganger3.Location.Y);

            }

            else

            {

                AutoRechts.Location = new Point(776, 190);

                AutoLinks.Location = new Point(-50, 260);

            }
        }  
        private void StoplichtGeelRO_Click(object sender, EventArgs e)
        {

        }

        private void Redstoplight2_Click(object sender, EventArgs e)
        {

        }

        private void Redstoplight_Click(object sender, EventArgs e)
        {

        }

        private void timer5_Tick(object sender, EventArgs e)
        {
            if (Blackcar.Top >= 2)

            {

                Blackcar.Location = new Point(Blackcar.Location.X, Blackcar.Location.Y - 50);

                voetganger1.Location = new Point(voetganger1.Location.X, voetganger1.Location.Y + 5);

                voetganger4.Location = new Point(voetganger4.Location.X, voetganger4.Location.Y - 5);

            }

            else

            {

                Blackcar.Location = new Point(445, 400);



            }
        }

        private void timer6_Tick(object sender, EventArgs e)
        {
            PolitieAuto.Location = new Point(PolitieAuto.Location.X , PolitieAuto.Location.Y + 100 );
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            timer1.Enabled = false;

            timer2.Enabled = false;

            timer3.Enabled = false;

            timer4.Enabled = false;

            timer5.Enabled = false;

            timer6.Enabled = false;

            timer7.Enabled = true;

            stoplightoff.Visible = true;

            stoplightoff1.Visible = true;

            stoplightoff2.Visible = true;

            stoplightoff3.Visible = true;

            Yellowstoplight.Visible = false;

            Yellowstoplight1.Visible = false;

            Yellowstoplight2.Visible = false;

            Yellowstoplight3.Visible = false;

            Redstoplight.Visible = false;

            Redstoplight1.Visible = false;

            Redstoplight2.Visible = false;

            Redstoplight3.Visible = false;

            Greenstoplight.Visible = false;

            Greenstoplight1.Visible = false;

            Greenstoplight2.Visible = false;

            Greenstoplight3.Visible = false;

            StoplichtVoetGreen1.Visible = false;

            StoplichtVoetGreen2.Visible = false;

            StoplichtVoetGreen3.Visible = false;

            StoplichtVoetGreen4.Visible = false;

            StoplichtVoetRed1.Visible = false;

            StoplichtVoetRed2.Visible = false;

            StoplichtVoetRed3.Visible = false;

            StoplichtVoetRed4.Visible = false;

            AutoRechts.Visible = false;

            AutoLinks.Visible = false;

            Blackcar.Visible = false;
        }

        private void timer7_Tick(object sender, EventArgs e)
        {
            if (stoplightoff.Visible == true)

            {

                stoplightoff.Visible = false;

                stoplightoff1.Visible = false;

                stoplightoff2.Visible = false;

                stoplightoff3.Visible = false;

                Yellowstoplight.Visible = true;

                Yellowstoplight1.Visible = true;

                Yellowstoplight2.Visible = true;

                Yellowstoplight3.Visible = true;

            }

            else if (Yellowstoplight.Visible == true)

            {

                stoplightoff.Visible = true;

                stoplightoff1.Visible = true;

                stoplightoff2.Visible = true;

                stoplightoff3.Visible = true;

                Yellowstoplight.Visible = false;

                Yellowstoplight1.Visible = false;

                Yellowstoplight2.Visible = false;

                Yellowstoplight3.Visible = false;
            }
           }
    }   
}
